package com.games.controller;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.games.dto.Team;
import com.games.rest.Schedule;
import com.games.service.TeamService;

@Controller
public class EntryController {
    @Autowired
    TeamService teamService;
    private static Log LOG = LogFactory.getLog(EntryController.class);
	
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@RequestMapping(value="/getSchedule",method=RequestMethod.POST)
	public @ResponseBody Schedule getSchedule(@RequestBody Team team,final HttpServletRequest request) {
		int teamSize= team.getTeamSize();
		Schedule schedule = teamService.getSchedule(teamSize);
		LOG.info("Returned result");
		LOG.debug("Response"+schedule.getResponse());
		LOG.debug("Status: "+schedule.getStatus());
		
	return schedule;
	}
	
}
