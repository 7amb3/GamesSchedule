package com.games.dao;

import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.games.calc.ScheduleCalc;
import com.games.constant.Constant;
import com.games.rest.Schedule;

@Component
public class GamesDAOImpl implements GamesDAO {


	private static Log LOG = LogFactory.getLog(GamesDAOImpl.class);
	
	@Override
	public Schedule getSchedule(int teamSize) {
		Schedule schedule = new Schedule();
		ScheduleCalc calc = new ScheduleCalc();
		List<String> games = calc.getSchedule(teamSize);
		LOG.debug("Size of games: "+games.size());
		if(games.size()>1 && games!=null) {
		    schedule.setResponse(games.toArray(new String[0]));
		    schedule.setStatus(Constant.CREATED_CODE);
		 }else {
			 schedule.setResponse(new String[0]);
			 schedule.setStatus(Constant.CONFLICT_CODE);
		 }
		return schedule;
	}

}
