package com.games.dao;

import com.games.rest.Schedule;

public interface GamesDAO {
public Schedule getSchedule(int teamSize);
}
