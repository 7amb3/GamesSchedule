package com.games.constant;

public class Constant {
   public static String CREATED_CODE ="201";
   public static String CONFLICT_CODE = "409";
}
