package com.games.rest;

import java.util.Arrays;

public class Schedule {

	String response ;
	String status;
	public String getResponse() {
		return response;
	}
	public void setResponse(String[] response) {
		this.response = Arrays.toString(response).replace('[', ' ').replace(']', ' ');
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
}
