package com.games.calc;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.games.rest.Schedule;


public class ScheduleCalc {
	
	public static boolean isPlayed(int l[],int ix,int iy) {
		boolean played = false;
		for(int i=0;i<l.length;i++) {
			if((ix==i && l[i]==1) || (iy==i && l[i]==1)) {
				played = true;
				break;
			}
			
		}
		return played;
	}
    
	
	public static void reset(int l[],String a[],String b[],int ix,int iy) {
		int ax = Integer.parseInt(a[0]);
		int ay = Integer.parseInt(a[1]);
		int bx = Integer.parseInt(b[0]);
		int by = Integer.parseInt(b[1]);
		
		for(int i=0;i<l.length;i++) {
		   if(i!= ax-1 && i!= ay-1 && i != bx-1 && i!= by-1 && i!=ix && i!=iy) {
			   l[i] = 0;
		   }	
			
		}
		
		
	}
	
	public static void reset(int l[],String a[],int ix,int iy) {
		int ax = Integer.parseInt(a[0]);
		int ay = Integer.parseInt(a[1]);
		
		for(int i=0;i<l.length;i++) {
		   if(i!= ax-1 && i!= ay-1 && i!= ix && i!=iy) {
			   l[i] = 0;
		   }	
		}	
	}
	
	public static void reset(int l[],String a[]) {
		int ax = Integer.parseInt(a[0]);
		int ay = Integer.parseInt(a[1]);
		
		for(int i=0;i<l.length;i++) {
		   if(i!= ax-1 && i!= ay-1 ) {
			   l[i] = 0;
		   }	
		}	
	}
	
	
	public static List<String> getSorted(List<String> l) {
		
		List<String> s = new ArrayList<String>();
		int d = l.size()/2;
		for(int i=0,j=l.size()-1;i<d && j>d;i++,j--) {
			s.add(l.get(i));
			s.add(l.get(j));
		}
		s.add(l.get(d));
		
		
		return s ; 
		
	}	

	public List<String> getSchedule(int teamSize) {
		  
		
		  int n=teamSize;
		  int teams[] = new int[n];
		  int home[] = new int[n];
		  int away[] = new int[n];
		  int last[] = new int[n];
		  String x = null;
		  for(int i=0;i<n;i++) {
			  teams[i] = i+1;
		  }
		  List<String> fix = new ArrayList<String>();
		  for(int i=0;i<n;i++){
			  for(int j=0;j<n;j++) {
				  if(i!=j) {
					  x = teams[i]+"-vs-"+teams[j];
				    fix.add(x);
				  }
			  }//inner for ends
		  }//outer for ends
		  
		  List<String> games = new ArrayList<String>();
		  int check = 0;
		  boolean done = true;
		  while(fix.size()!=0) {
			  done = true;
	      for(int i=0;i<n;i++) {
	    	  for(int j = 0;j<n;j++) {
	    		  if(i!=j) {
	    			 x =  teams[i]+"-vs-"+teams[j];
	    			 if(games.size()!=0) {
	    				 if(!isPlayed(last,i,j) && !games.contains(x) && games.size()==1) {
	    					 games.add(x);
	    					 home[i] += 1;
	        				 away[j] += 1;
	        				 last[i] = 1;
	        				 last[j] = 1;
	        				 check = 2;
	        				 done = false;
	    				 }else if(!isPlayed(last,i,j) && !games.contains(x) && (games.size()%2==1)) {
	    					 games.add(x);
	    					 home[i] += 1;
	        				 away[j] += 1;
	        				 last[i] = 1;
	        				 last[j] = 1;
	        				 reset(last,games.get(games.size()-2).split("-vs-"),games.get(games.size()-3).split("-vs-"),i,j);
	    					check = 3; 
	    					done = false;
	    				 }else if(!isPlayed(last,i,j) && !games.contains(x) && (games.size()%2==0)) {
	    					 games.add(x);
	    					 home[i] += 1;
	        				 away[j] += 1;
	        				 last[i] = 1;
	        				 last[j] = 1;
	        				 reset(last,games.get(games.size()-2).split("-vs-"),i,j);
	    					check = 2; 
	    					done = false;
	    					 
	    				 }
	    				 
	    			 }else if(games.size()==0) {
	    				 games.add(x);
	    				 home[i] += 1;
	    				 away[j] += 1;
	    				 last[i] = 1;
	    				 last[j] = 1;
	    				 done = false ;
	    			 }
	    			  
	    		  }//if for i!=j
	    	  }//Inner for
	       }//outer for
	      fix.removeAll(games);
	      
	      if(done == true)
	    	  break;
		  }//while
		  
		  List<String> list = getSorted(fix);
		  games.addAll(list);

		return games;
		
	}
	
	

}
