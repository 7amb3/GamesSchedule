package com.games.service;

import com.games.rest.Schedule;

public interface TeamService {
public Schedule getSchedule(int teamSize);
}
