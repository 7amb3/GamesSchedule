package com.games.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.games.dao.GamesDAO;
import com.games.rest.Schedule;
@Service
public class TeamServiceImpl implements TeamService{

	@Autowired
	GamesDAO gamesDAO;
	
	@Override
	public Schedule getSchedule(int teamSize) {
		
		return gamesDAO.getSchedule(teamSize);
	}

}
